:mod:`gtda.pipeline`: Pipeline
==============================

.. automodule:: gtda.pipeline
   :no-members:
   :no-inherited-members:

.. currentmodule:: gtda

.. autosummary::
   :toctree: generated/base/
   :template: class.rst

   pipeline.Pipeline

.. autosummary::
   :toctree: generated/
   :template: function.rst

   pipeline.make_pipeline