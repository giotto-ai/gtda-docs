:mod:`gtda.base`: Base
======================
.. automodule:: gtda.base
   :no-members:
   :no-inherited-members:

.. currentmodule:: gtda

.. autosummary::
   :toctree: generated/base/
   :template: class.rst

   base.TransformerResamplerMixin
   base.PlotterMixin
