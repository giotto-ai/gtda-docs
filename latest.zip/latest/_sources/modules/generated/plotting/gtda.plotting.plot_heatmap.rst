plot_heatmap
==============================================

.. currentmodule:: gtda.plotting

.. autofunction:: plot_heatmap

..
    Exclude sphinx-gallery generated examples since we use binder for now
    include:: gtda.plotting.plot_heatmap.examples

.. raw:: html

    <div class="clearer"></div>