plot_betti_surfaces
=====================================================

.. currentmodule:: gtda.plotting

.. autofunction:: plot_betti_surfaces

..
    Exclude sphinx-gallery generated examples since we use binder for now
    include:: gtda.plotting.plot_betti_surfaces.examples

.. raw:: html

    <div class="clearer"></div>