plot_diagram
==============================================

.. currentmodule:: gtda.plotting

.. autofunction:: plot_diagram

..
    Exclude sphinx-gallery generated examples since we use binder for now
    include:: gtda.plotting.plot_diagram.examples

.. raw:: html

    <div class="clearer"></div>