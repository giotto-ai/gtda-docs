plot_betti_curves
===================================================

.. currentmodule:: gtda.plotting

.. autofunction:: plot_betti_curves

..
    Exclude sphinx-gallery generated examples since we use binder for now
    include:: gtda.plotting.plot_betti_curves.examples

.. raw:: html

    <div class="clearer"></div>