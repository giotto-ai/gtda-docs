TransitionGraph
=========================================

.. currentmodule:: gtda.graphs

.. autoclass:: TransitionGraph

   
   .. automethod:: __init__
   

..
   Exclude sphinx-gallery generated examples since we use binder for now
   include:: gtda.graphs.TransitionGraph.

.. raw:: html

    <div class="clearer"></div>