GraphGeodesicDistance
===============================================

.. currentmodule:: gtda.graphs

.. autoclass:: GraphGeodesicDistance

   
   .. automethod:: __init__
   

..
   Exclude sphinx-gallery generated examples since we use binder for now
   include:: gtda.graphs.GraphGeodesicDistance.

.. raw:: html

    <div class="clearer"></div>