Binarizer
===================================

.. currentmodule:: gtda.images

.. autoclass:: Binarizer

   
   .. automethod:: __init__
   

..
   Exclude sphinx-gallery generated examples since we use binder for now
   include:: gtda.images.Binarizer.

.. raw:: html

    <div class="clearer"></div>