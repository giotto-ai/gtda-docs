PlotterMixin
====================================

.. currentmodule:: gtda.base

.. autoclass:: PlotterMixin

   
   .. automethod:: __init__
   

..
   Exclude sphinx-gallery generated examples since we use binder for now
   include:: gtda.base.PlotterMixin.

.. raw:: html

    <div class="clearer"></div>