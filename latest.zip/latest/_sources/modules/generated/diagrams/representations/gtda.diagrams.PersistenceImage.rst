PersistenceImage
============================================

.. currentmodule:: gtda.diagrams

.. autoclass:: PersistenceImage

   
   .. automethod:: __init__
   

..
   Exclude sphinx-gallery generated examples since we use binder for now
   include:: gtda.diagrams.PersistenceImage.

.. raw:: html

    <div class="clearer"></div>