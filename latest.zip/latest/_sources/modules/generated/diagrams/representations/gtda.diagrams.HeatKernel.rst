HeatKernel
======================================

.. currentmodule:: gtda.diagrams

.. autoclass:: HeatKernel

   
   .. automethod:: __init__
   

..
   Exclude sphinx-gallery generated examples since we use binder for now
   include:: gtda.diagrams.HeatKernel.

.. raw:: html

    <div class="clearer"></div>