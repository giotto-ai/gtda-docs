check_diagrams
=============================================

.. currentmodule:: gtda.utils

.. autofunction:: check_diagrams

..
    Exclude sphinx-gallery generated examples since we use binder for now
    include:: gtda.utils.check_diagrams.examples

.. raw:: html

    <div class="clearer"></div>