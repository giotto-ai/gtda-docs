check_collection
===============================================

.. currentmodule:: gtda.utils

.. autofunction:: check_collection

..
    Exclude sphinx-gallery generated examples since we use binder for now
    include:: gtda.utils.check_collection.examples

.. raw:: html

    <div class="clearer"></div>