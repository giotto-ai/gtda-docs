validate_params
==============================================

.. currentmodule:: gtda.utils

.. autofunction:: validate_params

..
    Exclude sphinx-gallery generated examples since we use binder for now
    include:: gtda.utils.validate_params.examples

.. raw:: html

    <div class="clearer"></div>