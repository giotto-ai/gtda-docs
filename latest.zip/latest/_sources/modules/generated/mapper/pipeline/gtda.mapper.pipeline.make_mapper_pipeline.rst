make_mapper_pipeline
=============================================================

.. currentmodule:: gtda.mapper.pipeline

.. autofunction:: make_mapper_pipeline

..
    Exclude sphinx-gallery generated examples since we use binder for now
    include:: gtda.mapper.pipeline.make_mapper_pipeline.examples

.. raw:: html

    <div class="clearer"></div>