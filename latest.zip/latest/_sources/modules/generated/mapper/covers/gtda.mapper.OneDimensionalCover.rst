OneDimensionalCover
=============================================

.. currentmodule:: gtda.mapper

.. autoclass:: OneDimensionalCover

   
   .. automethod:: __init__
   

..
   Exclude sphinx-gallery generated examples since we use binder for now
   include:: gtda.mapper.OneDimensionalCover.

.. raw:: html

    <div class="clearer"></div>