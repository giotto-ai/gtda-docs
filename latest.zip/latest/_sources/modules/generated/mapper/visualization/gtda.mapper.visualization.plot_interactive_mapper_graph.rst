plot_interactive_mapper_graph
===========================================================================

.. currentmodule:: gtda.mapper.visualization

.. autofunction:: plot_interactive_mapper_graph

..
    Exclude sphinx-gallery generated examples since we use binder for now
    include:: gtda.mapper.visualization.plot_interactive_mapper_graph.examples

.. raw:: html

    <div class="clearer"></div>