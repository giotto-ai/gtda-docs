Nerve
===============================

.. currentmodule:: gtda.mapper

.. autoclass:: Nerve

   
   .. automethod:: __init__
   

..
   Exclude sphinx-gallery generated examples since we use binder for now
   include:: gtda.mapper.Nerve.

.. raw:: html

    <div class="clearer"></div>