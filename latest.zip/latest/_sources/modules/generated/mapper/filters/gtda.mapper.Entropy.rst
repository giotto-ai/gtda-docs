Entropy
=================================

.. currentmodule:: gtda.mapper

.. autoclass:: Entropy

   
   .. automethod:: __init__
   

..
   Exclude sphinx-gallery generated examples since we use binder for now
   include:: gtda.mapper.Entropy.

.. raw:: html

    <div class="clearer"></div>