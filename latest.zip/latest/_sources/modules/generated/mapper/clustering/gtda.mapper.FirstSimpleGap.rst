FirstSimpleGap
========================================

.. currentmodule:: gtda.mapper

.. autoclass:: FirstSimpleGap

   
   .. automethod:: __init__
   

..
   Exclude sphinx-gallery generated examples since we use binder for now
   include:: gtda.mapper.FirstSimpleGap.

.. raw:: html

    <div class="clearer"></div>