FirstHistogramGap
===========================================

.. currentmodule:: gtda.mapper

.. autoclass:: FirstHistogramGap

   
   .. automethod:: __init__
   

..
   Exclude sphinx-gallery generated examples since we use binder for now
   include:: gtda.mapper.FirstHistogramGap.

.. raw:: html

    <div class="clearer"></div>