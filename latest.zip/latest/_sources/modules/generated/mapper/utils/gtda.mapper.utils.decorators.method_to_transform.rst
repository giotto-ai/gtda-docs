method_to_transform
====================================================================

.. currentmodule:: gtda.mapper.utils.decorators

.. autofunction:: method_to_transform

..
    Exclude sphinx-gallery generated examples since we use binder for now
    include:: gtda.mapper.utils.decorators.method_to_transform.examples

.. raw:: html

    <div class="clearer"></div>