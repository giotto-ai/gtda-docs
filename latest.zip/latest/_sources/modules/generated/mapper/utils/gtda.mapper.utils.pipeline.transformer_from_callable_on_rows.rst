transformer_from_callable_on_rows
================================================================================

.. currentmodule:: gtda.mapper.utils.pipeline

.. autofunction:: transformer_from_callable_on_rows

..
    Exclude sphinx-gallery generated examples since we use binder for now
    include:: gtda.mapper.utils.pipeline.transformer_from_callable_on_rows.examples

.. raw:: html

    <div class="clearer"></div>