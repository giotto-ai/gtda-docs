Stationarizer
============================================

.. currentmodule:: gtda.time_series

.. autoclass:: Stationarizer

   
   .. automethod:: __init__
   

..
   Exclude sphinx-gallery generated examples since we use binder for now
   include:: gtda.time_series.Stationarizer.

.. raw:: html

    <div class="clearer"></div>