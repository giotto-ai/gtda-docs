takens_embedding_optimal_parameters
========================================================================

.. currentmodule:: gtda.time_series

.. autofunction:: takens_embedding_optimal_parameters

..
    Exclude sphinx-gallery generated examples since we use binder for now
    include:: gtda.time_series.takens_embedding_optimal_parameters.examples

.. raw:: html

    <div class="clearer"></div>