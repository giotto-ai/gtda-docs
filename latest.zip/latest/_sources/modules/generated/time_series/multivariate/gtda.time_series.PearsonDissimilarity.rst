PearsonDissimilarity
===================================================

.. currentmodule:: gtda.time_series

.. autoclass:: PearsonDissimilarity

   
   .. automethod:: __init__
   

..
   Exclude sphinx-gallery generated examples since we use binder for now
   include:: gtda.time_series.PearsonDissimilarity.

.. raw:: html

    <div class="clearer"></div>