ConsecutiveRescaling
====================================================

.. currentmodule:: gtda.point_clouds

.. autoclass:: ConsecutiveRescaling

   
   .. automethod:: __init__
   

..
   Exclude sphinx-gallery generated examples since we use binder for now
   include:: gtda.point_clouds.ConsecutiveRescaling.

.. raw:: html

    <div class="clearer"></div>