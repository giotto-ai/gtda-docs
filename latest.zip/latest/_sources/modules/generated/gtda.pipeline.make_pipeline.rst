make_pipeline
===============================================

.. currentmodule:: gtda.pipeline

.. autofunction:: make_pipeline

..
    Exclude sphinx-gallery generated examples since we use binder for now
    include:: gtda.pipeline.make_pipeline.examples

.. raw:: html

    <div class="clearer"></div>